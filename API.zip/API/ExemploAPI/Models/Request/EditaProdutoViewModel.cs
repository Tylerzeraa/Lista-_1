﻿namespace ExemploAPI.Models.Request
{
	public class EditaProdutoViewModel
	{
		public string Descricao { get; set; }
		public decimal Preco { get; set; }
		public int Estoque { get; set; }
	}
}
