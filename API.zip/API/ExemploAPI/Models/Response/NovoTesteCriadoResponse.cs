﻿namespace ExemploAPI.Models.Response
{
	public class NovoTesteCriadoResponse
	{
		public bool sucesso { get; set; }
		public string mensagem { get; set; }
	}
}
